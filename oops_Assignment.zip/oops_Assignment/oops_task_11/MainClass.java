package com.yash.oops_task_11;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainClass {

	public static void main(String[] args) throws ParseException {
		
		
		String birth = "14/10/1997";
		Date dob = new SimpleDateFormat("dd/MM/yyyy").parse(birth);
		String join = "09/07/2017";
		Date doj = new SimpleDateFormat("dd/MM/yyyy").parse(join);
		
		Employee e=new Employee(101, "Arav", 28000.00, "Indore", dob, doj);
		
		System.out.println("Employee Details are: "+e.toString());

	}

}
