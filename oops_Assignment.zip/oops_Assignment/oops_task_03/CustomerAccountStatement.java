package com.yash.oops_task_03;

public class CustomerAccountStatement {
	private int CAID;
	private int CustID;
	private int amount;
	
	public CustomerAccountStatement(int cAID, int custID, int amount) {
		super();
		CAID = cAID;
		CustID = custID;
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "CustomerAccountStatement [CAID=" + CAID + ", CustID=" + CustID + ", amount=" + amount + "]";
	}
	
	
	
	
}
