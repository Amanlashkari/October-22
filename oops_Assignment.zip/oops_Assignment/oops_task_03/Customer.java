package com.yash.oops_task_03;

public class Customer {
	
	private int CustId;
	private int accountno;
	private String custname;
	private String cust_address;
	private String cust_dob; 
	private String cust_account_opening_date;
	private Branch Branch_Obj;
	
	public Customer(int custId, int accountno, String custname, String cust_address, String cust_dob,
			String cust_account_opening_date, Branch b1) {
		super();
		CustId = custId;
		this.accountno = accountno;
		this.custname = custname;
		this.cust_address = cust_address;
		this.cust_dob = cust_dob;
		this.cust_account_opening_date = cust_account_opening_date;
		Branch_Obj = b1;
	}

	@Override
	public String toString() {
		return "Customer [CustId=" + CustId + ", accountno=" + accountno + ", custname=" + custname + ", cust_address="
				+ cust_address + ", cust_dob=" + cust_dob + ", cust_account_opening_date=" + cust_account_opening_date
				+ ", Branch_Obj=" + Branch_Obj + "]";
	}

	
}
