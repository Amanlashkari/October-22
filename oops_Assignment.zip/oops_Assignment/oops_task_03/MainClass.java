package com.yash.oops_task_03;

public class MainClass {
	
	 public static void main(String[] args) 
	  {
		  System.out.println("BRANCH DETAILS: ");
		  
		  Branch b1 = new Branch(1001,"HDFC","Indore");
		  System.out.println("Details of branch-01:  ");
		  System.out.println(b1);
		  
		  Branch  b2 = new Branch(1002,"SBI","Pune");
		  System.out.println("\nDetails of branch-02:  ");
		  System.out.println(b2);
		  
		  Branch  b3 = new Branch(1003,"ICICI","Dhar");
		  System.out.println("\nDetails of branch-03:  ");
		  System.out.println(b3);
		  
		  System.out.println("\n========================================================================================================================================");
		  System.out.println("\n\nCustomer Details are: ");	
			
			Customer c1 = new Customer(101,30001,"Aman", "Lashkari","15/11/91\n","12/12/21", b1);
			System.out.println("\nDetails of customer-01 ");
			System.out.println(c1);
			
			Customer c2 = new Customer(102,30002,"Anmol", "Yadav","07/07/91\n","01/12/22", b2);
			System.out.println("\nDetails of customer-02 ");
			System.out.println(c2);
			
			Customer c3 = new Customer(103,30002,"Anil", "Sharma","05/03/95\n","01/02/20", b3);
			System.out.println("\nDetails of customer-03 ");
			System.out.println(c3);
			
			System.out.println("\n=========================================================================================================================================");
			System.out.println("\n\nAll the details of Customer_Account_Statement: ");
			
			CustomerAccountStatement ca1 = new CustomerAccountStatement(1001, 11, 5000);
			System.out.println("\nDetails of Customer_Account_Statement-01: ");
			System.out.println(ca1);
			
			CustomerAccountStatement ca2 = new CustomerAccountStatement(1002, 12, 6000);
			System.out.println("\nDetails of Customer_Account_Statement-02: ");
			System.out.println(ca2);
			
			CustomerAccountStatement ca3 = new CustomerAccountStatement(1003, 13, 9000);
			System.out.println("\nDetails of Customer_Account_Statement-03: ");			
			System.out.println(ca3);
		
	  }

}
