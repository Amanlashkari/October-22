package com.yash.oops_task_07;

public interface ComparisionOfString {
	public void compareString();

}
