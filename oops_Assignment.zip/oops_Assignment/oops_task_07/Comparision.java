package com.yash.oops_task_07;

import java.util.Scanner;

public class Comparision implements ComparisionOfString
{

	@Override
	public void compareString() 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First String: ");
		String st1=sc.next();
		
		System.out.println("Enter Second String: ");
		String st2=sc.next();
		
		char ch1[]=st1.toCharArray();
		char ch2[]=st2.toCharArray();
		
		for(int i=0;i<ch1.length;i++)
		{
			for(int j=0;j<ch2.length;j++)
			{
				if(ch1[i]==ch2[j])
				{
					System.out.println("Character is: "+ch1[i]+" from String 1 and 2 is: "+ch2[j]);
				}
			}
		}
	}
	public static void main(String[] args) 
	{
		ComparisionOfString c = new Comparision();
		c.compareString();
	}

}
