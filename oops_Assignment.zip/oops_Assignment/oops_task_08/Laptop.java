package com.yash.oops_task_08;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Laptop extends Electronics {
	
	public void laptopdetails() throws ParseException
	{
		Electronics ele=new Electronics();
		ele.setId(101);
		ele.setSemicondoctorType("copper");
		
		String date = "14/10/1997";
		Date dateofManufacturing = new SimpleDateFormat("dd/MM/yyyy").parse(date);
		
		System.out.println("laptop Details are: ");
		System.out.println("Id is: "+ele.getId());
		System.out.println("SemiconductorType: "+ele.getSemicondoctorType());
		System.out.println("Date of Manufacturing:  :-"+date);
	}

}
