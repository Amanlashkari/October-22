package com.yash.oops_task_08;

import java.text.ParseException;

public class MainClass {

	public static void main(String[] args) throws ParseException {
		
		Laptop l=new Laptop();
		l.laptopdetails();
		
		Mobile m=new Mobile();
		 m.mobiledetails();
		
		LCD lcd=new LCD();
		lcd.LCDDetails();
				

	}

}

//A instanceOfA = gotAFromSomewhere();
//B instanceOfB = constructBFrom(instanceOfA);
//instanceOfB.setPhone(getPhoneFromSomewhere());
//instanceOfB.setAddress(getAddressFromSomewhere());