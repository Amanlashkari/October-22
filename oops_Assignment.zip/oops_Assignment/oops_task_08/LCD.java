package com.yash.oops_task_08;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LCD extends Electronics {
	
	public void LCDDetails() throws ParseException
	{
		Electronics ele=new Electronics();
		ele.setId(103);
		ele.setSemicondoctorType("copper");
		
		String date = "09/03/1998";
		Date dateofManufacturing = new SimpleDateFormat("dd/MM/yyyy").parse(date);
		
		System.out.println("LCD Details are: ");
		System.out.println("Id is: "+ele.getId());
		System.out.println("SemiconductorType: "+ele.getSemicondoctorType());
		System.out.println("Date of Manufacturing:  :-"+date);
	}

}
