package com.yash.oops_task_08;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Electronics {
	
	private int id;
	private String semicondoctorType;
	private Date dateofManufacturing;
	

	public Date getDateofManufacturing() {
		return dateofManufacturing;
	}

	public void setDateofManufacturing(Date dateofManufacturing) {
		this.dateofManufacturing = dateofManufacturing;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSemicondoctorType() {
		return semicondoctorType;
	}

	public void setSemicondoctorType(String semicondoctorType) {
		this.semicondoctorType = semicondoctorType;
	}

	
	public void details() throws ParseException
	{
		Electronics ele=new Electronics();
		ele.setId(101);
		ele.setSemicondoctorType("copper");
		
		String date = "14/10/1997";
		Date dateofManufacturing = new SimpleDateFormat("dd/MM/yyyy").parse(date);
		
		System.out.println("Laptop Details: ");
		System.out.println("Id is: "+ele.getId());
		System.out.println("SemiconductorType: "+ele.getSemicondoctorType());
		System.out.println("Date of Manufacturing: "+date);
	}
	
	
	

}
