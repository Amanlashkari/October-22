package com.yash.oops_task_08;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Mobile extends Electronics {
		
	public void mobiledetails() throws ParseException
	{
		Electronics ele=new Mobile();
		ele.setId(102);
		ele.setSemicondoctorType("panel");
		
		String date = "03/09/1997";
		Date dateofManufacturing = new SimpleDateFormat("dd/MM/yyyy").parse(date);
		
		System.out.println("Mobile Details are: ");
		System.out.println("Id is: "+ele.getId());
		System.out.println("SemiconductorType: "+ele.getSemicondoctorType());
		System.out.println("Date of Manufacturing:-"+date);
		
	
	}
	
}
