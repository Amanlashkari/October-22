package com.yash.oops_task_02;

import java.util.Scanner;

public class Rectangle implements Shape {
	
	int xbreadth1, ybreadth1, xbreadth2, ybreadth2;
	int xlength1, xlength2, ylength1, ylength2;
	double length, breath;

	@Override
    public double area()
    {
    Scanner sc=new Scanner(System.in);
    
    System.out.println("Enter the coordinate of Length of x1 axis");
    int xlength1=sc.nextInt();
    int ylength1=sc.nextInt();
        
    System.out.println("Enter the coordinate of Length of x2 axis");
    int xlength2=sc.nextInt();
    int ylength2=sc.nextInt();
        
    double length1 =((xlength2-xlength1)*(xlength2-xlength1))+((ylength2-ylength1)*(ylength2-ylength1));
    length=Math.sqrt(length1);
    System.out.println("Enter the coordinate of Length of y1 axis");
    xbreadth1=sc.nextInt();
    ybreadth1=sc.nextInt();
     
     System.out.println("Enter the coordinate of Length of y2 axis");
     xbreadth2=sc.nextInt();
     ybreadth2=sc.nextInt();
   
    double breath1 =((xbreadth1-xlength1)*(xbreadth1-xlength1))+((ybreadth1-ylength1)*(ybreadth1-ylength1));  
    breath=Math.sqrt(breath1);
    System.out.println(length+" "+breath+" ");
    return length*breath;
    
    }
    public static void main(String[] args)
    {
    	Shape s=new Rectangle();
    	System.out.println(s.area()); 
    }	    
}              



