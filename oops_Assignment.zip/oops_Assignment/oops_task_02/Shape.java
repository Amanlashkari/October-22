package com.yash.oops_task_02;

public interface Shape {
	
	public double area();
}
