package com.yash.oops_task_06;

import java.util.Scanner;

public class MainClass {
	public static void main(String args[])
	{

		Scanner sc = new Scanner(System.in);
		System.out.println("Find from the maximum of 3 ,4 or 5 for n number");
		int n = sc.nextInt();

		if (n==3) 
		{
			System.out.println("Enter 3 digit number: ");
			int number = sc.nextInt();
			B class1 = new B();
			class1.Numbers(number);
		}

		if (n==4) 
		{
			System.out.println("Enter 4 digit number: ");
			int number = sc.nextInt();
			C class2 = new C();
			class2.Numbers(number);
		}

		if (n==5) 
		{
			System.out.println("Enter the 5 digit number: ");
			int number = sc.nextInt();
			D class3 = new D();
			class3.Numbers(number);
		}
	}
}
