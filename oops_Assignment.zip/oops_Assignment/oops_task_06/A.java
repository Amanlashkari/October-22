package com.yash.oops_task_06;

public class A {
	
	public void Numbers(int number) {
		System.out.println("Find from 3,4 numbers");
	}

	

}
