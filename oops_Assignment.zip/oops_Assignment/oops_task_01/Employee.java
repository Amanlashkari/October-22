package com.yash.oops_task_01;

import java.util.Date;

public class Employee extends Person {
	
	
	private double salary;
	private String date_of_joining;
	private String base_location;
	private Department deptobj;
	private int contactno;
	private String emailid;
	
	public Employee(int pid, String pname, String paddress, String string3, double d, String string4,
			String string, Department dept, int contactno, String string2) {
		super(pid, pname, paddress, string3);
		this.salary = d;
		this.date_of_joining = string4;
		this.base_location = string;
		this.deptobj = dept;
		this.contactno = contactno;
		this.emailid = string2;
	}
	
	public double getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public String getDate_of_joining() {
		return date_of_joining;
	}
	public void setDate_of_joining(String date_of_joining) {
		this.date_of_joining = date_of_joining;
	}
	public String getBase_location() {
		return base_location;
	}
	public void setBase_location(String base_location) {
		this.base_location = base_location;
	}
	public Department getDeptobj() {
		return deptobj;
	}
	public void setDeptobj(Department deptobj) {
		this.deptobj = deptobj;
	}
	public int getContactno() {
		return contactno;
	}
	public void setContactno(int contactno) {
		this.contactno = contactno;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	void printEmployeeDetails() {
		System.out.println("Employee ID : "+ pid 
				+"\nEmployee Name: "+pname+
				"\nAddress: "+paddress+
				"\nDOB: "+dob+
				"\nSalary: "+salary+
				"\nDate of Joining: "+date_of_joining+
				"\nBase Location: "+base_location+
				"\nDepartment: "+deptobj+
				"\nContact Number: "+contactno+
				"\nEmail-Id: "+emailid);
	}
	
	
}

