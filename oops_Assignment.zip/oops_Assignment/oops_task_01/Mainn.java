package com.yash.oops_task_01;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Mainn{
	
	public static void main(String[] args) throws ParseException 
	{
		Department[] department = new Department[2];
		
		department[0] = new Department("D101", "IT Department");
		department[1] = new Department("D102", "Network Department");

		
		Employee emp = new Employee(101, "Aman Lashkari", "Dhar", "14/10/1997", 20000, 
				"09/03/2021", 
				"Indore",department[1], 987654321,"amanlashkari@gmail.com");

		Customer cust = new Customer(1001, "Arav", "Indore", "14/10/1997", "13/11/2021",
				"Indore", 934321145, "arav@gmail.com");

		System.out.println("Employee Details: ");
		emp.printEmployeeDetails();
		 
		System.out.println("\nCustomer Details: ");
		cust.printCustomerDetails();
}
}
