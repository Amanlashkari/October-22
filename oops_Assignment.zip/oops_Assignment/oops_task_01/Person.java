package com.yash.oops_task_01;

import java.util.Date;

public class Person {
	
	protected int pid;
	protected String pname;
	protected String paddress;
	protected String dob;

	public Person(int pid, String pname, String paddress, String string) {
		this.pid = pid;
		this.pname = pname;
		this.paddress = paddress;
		this.dob = string;
	}

	int getPid() {
		return pid;
	}

	void setPid(int pid) {
		this.pid = pid;
	}

	String getPname() {
		return pname;
	}

	void setPname(String pname) {
		this.pname = pname;
	}

	String getPaddress() {
		return paddress;
	}

	void setPaddress(String paddress) {
		this.paddress = paddress;
	}

	String getDob() {
		return dob;
	}

	void setDob(String dob) {
		this.dob = dob;
	}
	
}
