package com.yash.oops_task_09;

public class Student 
{

	String name;

	public String getName() 
	{
		return name;
	}

	public void setName(String id) 
	{
		this.name = id;
	}

	@Override
	public String toString() 
	{
		return "Student [name=" + name + "]";
	}

	public Student(String name) 
	{
	        super();
	        this.name = name;
	}

	public Student() 
	{
	        super();
	        
	}

	@Override
	protected void finalize() throws Throwable 
	{
		System.out.println("name= " + this.name);
	}

}
