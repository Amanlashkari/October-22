package com.yash.oops_task_09;

public class Finalizemethod {
	
	 public static void main(String args[]) 
	 {
		 Student e1=new Student("Aman");
		 Student e2=new Student("Sahil");
	     Student e3=new Student("Anmol");
     
	     e3=null;
	     System.gc();
	            
	     for(int i=1; i<4; i++) 
	     {
	    	 String e="e"+i;
	    	 System.out.println(e+": "+e.hashCode());
	     }
	           // System.out.println("e2= "+e2);
	          //  System.out.println("e5= "+e5);          
	    }

}
