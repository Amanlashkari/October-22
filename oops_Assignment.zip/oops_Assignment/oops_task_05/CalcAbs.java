package com.yash.oops_task_05;

public abstract class CalcAbs
{
	public abstract void sum(int a, int b);
	
	public abstract void sub(int a, int b);
	
	public abstract void mul(int a, int b); 
	
	public abstract void div(int a,int b); 

}
