package com.yash.oops_task_05;

import java.util.Scanner;

public class D extends C{
	
	@Override
	public void div(int a,int b) {
		int c=a/b;
		System.out.println("Division is: "+c);
	}

	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		
		CalcAbs cal=new D();
		System.out.println("Enter two numbers to Sum: ");
		cal.sum(sc.nextInt(), sc.nextInt());
		
		System.out.println("Enter two numbers for Substraction: ");
		cal.sub(sc.nextInt(), sc.nextInt());
		
		System.out.println("Enter two numbers for Multiplication: ");
		cal.mul(sc.nextInt(), sc.nextInt());
		
		System.out.println("Enter two numbers for Division: ");
		cal.div(sc.nextInt(), sc.nextInt());
		
	}
}
