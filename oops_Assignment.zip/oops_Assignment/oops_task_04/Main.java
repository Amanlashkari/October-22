package com.yash.oops_task_04;

import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		
		CalculateArea calculatearea=new CalculateArea();
		calculatearea.areaOfRectangle(2,2,2);
		calculatearea.areaOfSquare(2,2,2);
		calculatearea.areaOfTraingle(2, 3, 4);
	}
}

class CalculateArea 
{

	void areaOfSquare(double length, double height, double width) 
	{	
		
		double Square = length * length;
		System.out.println("print area of Square-" + Square);
	}

	void areaOfRectangle(double length, double width, double height) 
	{
		double Rectangle = length * width;
		System.out.println("print area of Rectangle-" + Rectangle);
	}

	void areaOfTraingle(double length, double width, double height) 
	{
		double Traingle = length * width * height;
		System.out.println("print area of tringle-" + Traingle);
	}
}

