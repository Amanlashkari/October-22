package com.yash.oops_task_10;

public class TestClass 
{
		public static void main(String[] args)
		{	
			Product pro=new Product(1001, "Geera", 1000, "ML");  
			
	        Product product = null;
			try {
				product = (Product) pro.clone();
			} catch (CloneNotSupportedException e) {
				
				e.printStackTrace();
			}
	        product.setPname("Appy");
	        product.setPrice(50);
	        
	        System.out.println(product);
	        if(product instanceof Product) 
	        { 
	            System.out.println("Objects are same: ");
	        }	     
		}

	}

