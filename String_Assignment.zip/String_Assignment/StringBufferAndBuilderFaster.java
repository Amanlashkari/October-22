package com.yash.String_Assignment;

public class StringBufferAndBuilderFaster 
{
	public static void main(String[] args)
    {  
     long startTime = System.currentTimeMillis();  
     
     StringBuffer stringbuilder = new StringBuffer("Aman");  
     for (int i=0; i<10000; i++)
     {  
    	 stringbuilder.append("Lashkari");  
     }  
     System.out.println("Time is taken by StringBuffer: " + (System.currentTimeMillis() - startTime) + "ms");  
  
     startTime = System.currentTimeMillis();  
     StringBuilder stringbuilder2 = new StringBuilder("Aman");  
     for (int i=0; i<10000; i++)
     {  
    	 stringbuilder2.append("Lashkari");  
     }  
     System.out.println("Time is taken by StringBuilder: " + (System.currentTimeMillis() - startTime) + "ms");  
    }
}
