package com.yash.String_Assignment;

public class HeapMemoryAllocation{

		public static void main(String[] args)
		{
			String string1 = "Aman";
			String string2 = "Aman";

			String string3 = new String("Lashkari");
			String string4 = new String("Lashkari");
			
	        System.out.println("string1: "+string1.hashCode());
	        System.out.println("string2: "+string2.hashCode());
	        System.out.println("string3: "+string3.hashCode());
	        System.out.println("string4: "+string4.hashCode());
	         
			//In scp
			if (string1==string2)
				System.out.println("Yes");
			else
				System.out.println("No");

			// In Heap Memory
			if (string3==string4)
				System.out.println("Yes");
			else
				System.out.println("No");
			
		}
}

