package com.yash.String_Assignment;

public class GarbageCollector {
	
		String s;
	    public GarbageCollector(String str) 
	    {
	    	this.s = str;
		}
		@Override
		protected void finalize() throws Throwable
		{
			super.finalize();
			System.out.println(this.s + " is Collected");
		}
		public static void main(String[] args) 
		{
			GarbageCollector gcc = new GarbageCollector("Aman");
			System.out.println("String is: " + gcc.s.toString());
			gcc = null;
		    System.gc();
		}
	}
