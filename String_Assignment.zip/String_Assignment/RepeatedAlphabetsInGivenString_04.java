// WAP to print the number of alphabets repeated in the given string.

package com.yash.String_Assignment;

public class RepeatedAlphabetsInGivenString_04 
{
	public static void main(String args[]) 
	{
		String str="AmanLashkari";
		char [] s=str.toCharArray();
		
		for(int i=0; i<s.length;i++) 
		{
			int Count=1;
            for(int j=i+1; j<s.length; j++)
            {
                if(s[i]==s[j])
                {
                    Count++;      
                }    
            }
            if(Count > 1)
            {
                System.out.println(s[i]+" Number of times: "+Count);
            }
        }
	}
}

