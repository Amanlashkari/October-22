package com.yash.Array_Assignment;

public class EvenOddPrimePerfectNumber {
	public static void main(String args[]) 
	{
	int a[]= {1,2,3,4,5};
	int sum=0;
    int i1=1;  
	for(int i=0;i<a.length;i++) {
		if(a[i]%2==0) 
		{
			System.out.println("Number is even: "+a[i]);
		}
		else
		{
			System.out.println("Number is odd: "+a[i]);
		}
	    while(i1<=a[i]/2)  
	    {  
	    	if(a[i] % i1==0)  
	    	{  
	           sum=sum+i1;  
	        }   
	        i++;  
	        }   
	        if(sum==a[i])  
	        {  
	    	   System.out.println(a[i]+" is a perfect number.");  
	        }  
	        else
	    	   System.out.println(a[i]+" is not a perfect number.");   
	    }
	}
}

