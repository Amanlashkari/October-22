package com.yash.Array_Assignment;

public class SortByUnitPlace {
	
	  public static void main(String[] args)
	  {
		  int[][] a ={{10,20,40},{50,60},{90,80,70}};

		 // System.out.println(a[0][0].length);
	  }   

}
