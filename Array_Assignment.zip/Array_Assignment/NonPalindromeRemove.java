package com.yash.Array_Assignment;

public class NonPalindromeRemove {

	public static void main(String[] args) {
		String[] arr = { "nayan", "jalaj", "raju", "raj", "saas" };
		for (int i=0; i<arr.length; i++) {
			if (arr[i].equalsIgnoreCase(isPalindrome(arr[i]))) {
				System.out.print(arr[i] + " ");
			}
		}
	}
	public static String isPalindrome(String reverse) {
		String temp = reverse;
		String rev = "";
		for (int i = temp.length() - 1; i >= 0; i--) {
			rev = rev + temp.charAt(i);
		}
		return rev;
	}
}