package com.yash.Array_Assignment;

public class ArraySortByLength
{
	 public static void main(String[] args)
	    {
	         String a[]={"You know who I am.","You don't know ","where","I am.","And you'll never see me coming."};
             String temp;
	         for(int i=0; i<a.length; i++)
	         {                
	        	 for(int j=i+1; j<a.length; j++)
	             {
	        		 if (a[i].length() > a[j].length())
	                 {
	        			 temp = a[i];
	                     a[i] = a[j];
	                     a[j] = temp;
	                 }
	             }
	        	 System.out.println(a[i]);
	         }
	    }
}
