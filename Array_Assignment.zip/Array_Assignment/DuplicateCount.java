package com.yash.Array_Assignment;

public class DuplicateCount {
	public static void main(String[] args) {
		
		int[] array = {15,45,23,77,65,45,12,23,77};
		for (int i=0; i<array.length; i++) {
			
			int count=1;
			for(int j=i+1;j<array.length;j++)
			{
				if(array[i]==0)
					continue;
				if(array[i]==array[j])
				{
					count++;	
					array[j]=0;
				}
			}
			if(count>1)
				System.out.println("Numbers are: "+array[i]+" "+"\nNumbers of times: "+count);
		}
	}
}
